**Remark (LP DAAC Data Pool <a href="https://lpdaac.usgs.gov/data_access/data_pool">https://lpdaac.usgs.gov/data_access/data_pool</a>):**
**"As of July 20, 2016, users are now required to log in with their Earthdata login credentials to obtain data. When accessing data via the Data Pool direct access links, you will now be prompted to enter your credentials. Script users should modify their code to reflect this change. For examples please see the Command Line Tips document".**

**In this regard, version modis_downloader awaiting updates... :(**
